<?php require_once('includes/functions.php'); ?>
<!-- If user is registed and does not have any errors, go to index.php page -->
<?php
    $errors = [];
    if(isset($_POST['login'])) {
        $errors = loginUser($_POST);

         if(count($errors) === 0) {
            header('Location: index.php');
            echo "<script>alert('Login Successful!');</script>";
            exit();
        }
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <link
            rel="stylesheet"
            href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
            crossorigin="anonymous"
        />
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
            integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w=="
            crossorigin="anonymous"
        />
        <link rel="stylesheet" href="./style/main.css" />
        <title>Covid Wait App</title>
</head>


<body>
<header>
<?php require_once "./includes/header.php" ?>
    </header>
    <div>
        <h1>Login Form</h1> 
    </div><br>
    
     <!-- Creating Log In form -->
<div class="login">
    <div class="row">
        <div class="col-md-6">
            <form method="post">
                <div class="form-group">
                    <!-- Validating Email -->
                    <label for="email"style =  "color: #fff">Email</label>
                    <input type="text" class="form-control" id="email" name="email"
                        <?php displayValue($_POST, 'email'); ?> />
                         <?php displayError($errors, 'email'); ?>
                </div>

                <div class="form-group">
                    <!-- Validating Password -->
                    <label for="phone" style =  "color: #fff">Password</label>
                    <input type="password" class="form-control" id="password" name="password" />
                    <?php displayError($errors, 'password'); ?>
                </div>

                <button type="submit" class="btn btn-primary" name="login" value="login" style = "font-size: 20px; ">Login</button>

            </form>
        </div>
    </div>

</body>
</html>
