<?php require_once('includes/functions.php'); ?>
<!-- If user is registed and does not have any errors, go to login.php page -->
<?php
    $errors = [];
    if(isset($_POST['registration'])) {
        $errors = registerUser($_POST);

        if(count($errors) === 0) {
            echo "<script>alert('Registration Successful!');</script>";
            header("Location: login.php");
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <link
            rel="stylesheet"
            href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
            crossorigin="anonymous"
        />
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
            integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w=="
            crossorigin="anonymous"
        />
        <link rel="stylesheet" href="./style/main.css" />
        <title>Covid Wait App</title>
</head>


<body>
<header>
<?php require_once "./includes/header.php" ?>
    </header>
    <div>
        <h1>Registration Form</h1> 
    </div><br>
    
    <div class ="registration">
        <div class="row">
            <div class="col-md-6">
                <form method="post">
                    <div class="form-group">
                        <!-- Validate Firstname -->
                        <label for="firstname" style =  "color: #fff" >*First name</label>
                        <input type="text" class="form-control" id="firstname" name="firstname"
                            <?php displayValue($_POST, 'firstname'); ?> />
                        <?php displayError($errors, 'firstname'); ?>
                    </div>

                    <div class="form-group">
                        <!-- Validate Lastname -->
                        <label for="lastname" style =  "color: #fff">*Last name</label>
                        <input type="text" class="form-control" id="lastname" name="lastname"
                            <?php displayValue($_POST, 'lastname'); ?> />
                        <?php displayError($errors, 'lastname'); ?>
                    </div>

                    <div class="form-group">
                        <!-- Validate Email -->
                        <label for="lastname" style =  "color: #fff">*Email</label>
                        <input type="text" class="form-control" id="email" name="email"
                            <?php displayValue($_POST, 'email'); ?> />
                        <?php displayError($errors, 'email'); ?>
                    </div>


                    <div class="form-group">
                        <!-- Validate Password -->
                        <label for="password" style =  "color: #fff">*Password <small class="text-muted">must be at least 6 characters</small></label>
                        <input type="password" class="form-control" id="password" name="password" />
                        <?php displayError($errors, 'password'); ?>
                    </div>

                    <div class="form-group">
                        <!-- Validate Confirm Password -->
                        <label for="password" style =  "color: #fff">*Confirm password</label>
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" />
                        <?php displayError($errors, 'confirmPassword'); ?>
                    </div>

                    <button type="submit" class="btn btn-primary" name="registration" value="Registration" style = "font-size: 20px; " >Register</button>
              
                </form><br><br>
            </div>
        </div>
    </div>

</body>
</html>
