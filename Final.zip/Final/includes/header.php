<?php require_once('includes/functions.php'); ?>
<header>
    <div class="logo">
        <a href="/"
            ><h1 class="text-center">
                Covid Wait Time<i class="far fa-clock"></i></h1
        ></a>
    </div>
    <div class="topnav" id="myTopnav">
	<!-- Both logged in and not logged in user can see this in navbar -->
                <a href="index.php">Home</a>
                <a href="checkin.php">Check-in</a>
				<a href="vaccination.php">Vaccination</a>
<!-- If user is logged in show: -->
                <?php if(isUserLoggedIn()) { ?>
                     <a href="logout.php">Logout</a>
                <?php } ?>
                <?php if(isUserLoggedIn()) { ?>
                    <span class="nav-item nav-link text-light mx-2" style="font-size:20px;">
                        Welcome, <?= getLoggedInUser()['firstname']; ?>
                    </span>
              
                <?php } else { ?>
<!-- If user is not logged in show: -->
                      <a href="register.php">Register</a>
					  <a href="login.php">Login</a>
                <?php } ?>
    </div>
</header>