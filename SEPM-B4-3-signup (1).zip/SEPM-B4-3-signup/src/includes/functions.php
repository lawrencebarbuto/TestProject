<?php
   
    const LOCATIONS_PATH = 'data/locations.json';
    const USERS_PATH = 'data/users.json';


    // Always call session_start.
    session_start();

    // --- Utils ----------------------------------------------------------------------------------
    function readJsonFile($path) {
        $json = file_get_contents(__DIR__ . $path);

        return json_decode($json, true);
    }

    function updateJsonFile($data, $path) {
        $json = json_encode($data, JSON_PRETTY_PRINT);
        file_put_contents($path, $json, LOCK_EX);
    }

    function displayError($errors, $name) {
        if(isset($errors[$name]))
            echo "<div class='text-danger'>{$errors[$name]}</div>";
    }

    function displayValue($form, $name) {
        if(isset($form[$name]))
            echo 'value="' . htmlspecialchars($form[$name]) . '"';
    }

    function generatePasswordHash($password, $salt = null) {
        if($salt === null)
            $salt = bin2hex(openssl_random_pseudo_bytes(10));
        $blowfish_salt = '$2y$10$' . $salt;

        return crypt($password, $blowfish_salt);
    }

    // Use for verifying password hash
    function verifyPasswordHash($password, $hash) {
        $tokens = explode('$', $hash);
        $salt = $tokens[3];

        return $hash === generatePasswordHash($password, $salt);
    }

   
    
    // --- Locations -----------------------------------------------------------------------------
    function readLocations() {
        return readJsonFile(LOCATIONS_PATH);
    }

    function getLocations($location) {
        $locations = readLocations();

        return isset($locations[$location]) ? $locations[$location] : null;
    }


 
 // --- User -----------------------------------------------------------------------------------
 function readUsers() {
    return readJsonFile(USERS_PATH);
}

function updateUsers($users) {
    updateJsonFile($users, USERS_PATH);
}

function getUser($email) {
    $users = readUsers();

    return isset($users[$email]) ? $users[$email] : null;
}


// Validating registered user
function registerUser($form) {
    $errors = [];
// Validating firstname
    $key = 'firstname';
    if(!isset($form[$key]) || preg_match('/^\s*$/', $form[$key]) === 1)
        $errors[$key] = 'First name is required.';
// Validating lastname
    $key = 'lastname';
    if(!isset($form[$key]) || preg_match('/^\s*$/', $form[$key]) === 1)
        $errors[$key] = 'Last name is required.';
// Validating email
    $key = 'email';
    if(!isset($form[$key]) || filter_var($form[$key], FILTER_VALIDATE_EMAIL) === false)
        $errors[$key] = 'Email is invalid.';
    else if(getUser($form[$key]) !== null)
        $errors[$key] = 'Email is already registered.';

// Validating password
    $key = 'password';
    if (strlen($form['password']) <= 6) {
        $errors[$key] = "Your Password Must Contain At Least 6 Characters!";
    }
    elseif(!preg_match('/[A-Z]{1,}/',$form[$key])) {
        $errors[$key] = "Your Password Must Start with a Capital Letter!";
    
    }
    elseif(!preg_match('/(?=[!^&])/',$form[$key])) {
        $errors[$key] = "Your Password Must Contain Either !, ^, &";
    
    }
    
    elseif(!preg_match('/[0-9]$/',$form[$key])) {
        $errors[$key] = "Your Password Must End with a Number!";
    }

// Validating confirm password
    $key = 'confirmPassword';
    if(isset($form['password']) && (!isset($form[$key]) || $form['password'] !== $form[$key]))
        $errors[$key] = 'Passwords do not match.';

    
//If there are no errors, proceed
    if(count($errors) === 0) {
        // Add user.
        $user = [
            'firstname' => htmlspecialchars(trim($form['firstname'])),
            'lastname' => htmlspecialchars(trim($form['lastname'])),
            'email' => htmlspecialchars(trim($form['email'])),
            'password-hash' => generatePasswordHash($form['password']),
      
        ];

        $users = readUsers();
        $users[$user['email']] = $user;

        // Update file.
        updateUsers($users);    
        
    }

    return $errors;
}