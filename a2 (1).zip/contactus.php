<?php require_once('includes/functions.php'); ?>
<!DOCTYPE html>
<html lang="en">
<title>Contact Us</title>

<head>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/body.php'); ?>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <!-- include the plugin -->
      <script src="plugin/jquery.validate.js"></script>
      <!-- write the JS code to play with the plugin -->
      <script src="plugin/form-validation.js"></script>
      </head>
<style>

        /* Making Banner */
        .banner {
            width: 1885px;
            height: 150px;
            color: white;
            line-height: 150px;
            font-size: 70px;
            grid-area: banner;
            text-align: center;
            text-transform: uppercase;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background: black;
            border-width: 1px;
        }

        p {
            text-align: top;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            font-size: 70px;
            color: white;
        }

        /* Designing contactus form */
        .contactus {
            width: 1885px;
            height: 110%;
            color: white;
            line-height: 50px;
            grid-area: content;
            text-align: center;
            background-color: rgba(44, 44, 44, 0.8);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            border-width: 1px;
        }

        p.one {
            margin-block-start: 1em;
            margin-block-end: 0;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            margin-left: 50px;
            text-decoration: underline;
            font-size: 40px;
            color: white;
            font-family: fantasy;
        }

        p.two {
            margin-block-start: 0.3em;
            margin-block-end: 0;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            margin-left: 50px;
            font-size: 20px;
            line-height: 1.5;
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        p.three {
            margin-block-start: 0.3em;
            margin-block-end: 0;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            margin-left: 20px;
            font-style: bold;
            font-size: 35px;
            font-weight: 300px;
            line-height: 1.5;
            color: wheat;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        p.four {
            margin-block-start: 1em;
            margin-block-end: 0;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            margin-right: 50px;
            text-decoration: underline;
            font-size: 40px;
            color: white;
            font-family: fantasy;
        }

        p.five {
            margin-block-start: 0.3em;
            margin-block-end: 0;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            margin-right: 20px;
            font-style: bold;
            font-size: 35px;
            font-weight: 300px;
            line-height: 1.5;
            color: wheat;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Creating Link */
        a.two:link {
            margin-block-start: 0.3em;
            margin-block-end: 0;
            margin-inline-start: 0px;
            margin-inline-end: 0px;
            margin-left: 50px;
            font-size: 20px;
            color: white;
            text-align: center;
        }

        /* Creating form */
        form {
            display: grid;
            grid-template-columns: 400px 400px;
            grid-gap: 36px;
            justify-content: center;
            align-content: center;
        }
        label {
            color: white;
            font-size: 20px;
            justify-content: center;
            align-content: center;
        }

        input {
            color: black;
            font-size: 20px;
            justify-content: center;
            align-content: center;
        }

        .error {
      color: red;
      font-size:15px;
    
   }
        
</style>



<body>
    <!-- Putting Everything together on the page -->
    <?php require_once('includes/navbar.php'); ?>
        <div class="banner">
            <p>Contact Us</p>
        </div><br>
        <div class ="contactus">
            <br>
        <p class="one">Phone Number:</p>
            <p class="two">045 XXX XXX </p>
            <p class="one">Email:</p>
            <a class="two" href="mailto:admin@abcgym.com">admin@abcgym.com </a>
            <p class="one">FAQ</p>
            <p class="three">I want to cancel my membership<br></p>
            <p class="two">Just log in into your account and go to your profile and click cancel membership <br><br><br>
            </p>
            <p class="three">I got charged wrongly<br></p>
            <p class="two"> You can call us at our phone number or email us. You could also come to our gym to talk to
                us directly.<br>
                Hours of Support: <br>
                Monday - Friday = 8am - 6pm AEST <br>
                Saturday - Sunday = 10am - 4pm AEST <br><br><br></p>
            <p class="one">Inquiry <br><br></p>
            <div>
                <!-- When submit user sends email to admin@abcgym.com -->
            <form action="mailto:admin@abcgym.com" name="inquiry_form">
          <label style="height:40px; width:250px; font-size: 20px;" for="firstname">First Name: </label> 

          <input
            type="text"
            name="firstname"
            id="firstname"
          />

          <label style="height:40px; width:250px; font-size: 20px;" for="lastname">Last Name: </label>
          <input type="text" name="lastname" id="lastname"/>
       
          
          <label style="height:40px; width:250px; font-size: 20px;" for="email">Email:</label>
            <input
            type="email"
            name="email"
            id="email"

          />
        

          <label style="height:40px; width:250px; font-size: 20px;" for="phonenumber">Phone Number</label>
          <input
            type="tel"
            name="phonenumber"
            id="phonenumber"
          />
       
          <label style="height:40px; width:250px; font-size: 20px;" class="label">Inquiry:</label>
            <textarea name="inquiry" value="" id="inquiry"></textarea>
          
 

          <button style="height:70px; width:250px; font-size: 20px; margin-left: 200px;" type="submit">Submit</button>
          <br>
          <br>
        </form>

            </div>
        </div>

    <?php require_once('includes/footer.php'); ?>
</body>

</html>
