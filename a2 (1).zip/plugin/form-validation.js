// Validating Contact Us form
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='inquiry_form']").validate({
    // Specify validation rules
    rules: {
      // Validating firstname
      firstname: "required",
      // Validating lastname
      lastname: "required",
      // Validating email
      email: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      },
      // Validating phonenumber
      phonenumber: {
        required: true,
        number: true,
        minlength:10,
      }
    },
    // Specify validation error messages
    messages: {
      firstname: "Please enter your First Name",
      lastname: "Please enter your Last Name",
      phonenumber: "Please enter your Phone Number",
      email: "Please enter a valid Email address"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
});