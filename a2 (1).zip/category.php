<!-- User  must be logged in to access this page -->
<?php require_once('includes/authorise.php'); ?>
<?php
    $user = getLoggedInUser();
    $category = getCategory($_GET['category']);
    $userStats = getUserStatsForCategory($user['email'], $category['key']);
?>
<!DOCTYPE html>
<html lang="en">
    <title>Category</title>
<head>
    <?php require_once('includes/header.php'); ?>
    <?php require_once('includes/body.php'); ?>
</head>

<body>
    <?php require_once('includes/navbar.php'); ?>
<!-- Putting Everything together -->
    <div class="category bg-dark">
        <div class="mb-3 text-center text-light">
            <h1> <?= $category['name']; ?></h1><br>
            <h1>
                <img  class="border rounded" src="<?= $category['image']; ?>" class="d-block d-sm-inline-block" />
            </h1>
        </div>

        <div class="mb-3 text-center ">
                <a href="createActivity.php?category=<?= $category['key']; ?>" class="btn btn-primary mr-3">
                Record activity
            </a>
            <a href="myFitness.php" class="btn btn-outline-light">Back to myFitness</a>
        </div>

<!-- Show recorded activities -->
        <?php if(count($userStats) !== 0) { ?>
            <table class="table table-striped">
                <thead class="thead-light">
                    <br><br><tr>
                    
                        <th>Weight &nbsp;&nbsp;
                        <img src="assets/weight.png"/></th>  
                        <th>Height &nbsp;&nbsp;
                        <img src="assets/height.png"/></th>
                        <th>BMI &nbsp;&nbsp;
                        <img src="assets/bmi.png"/></th>
                      
                        <th>Date&nbsp;&nbsp;
                        <img src="assets/date.png"/></th>
                        <th>Weekly Goal &nbsp;&nbsp;
                        <img src="assets/duration.png"/></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($userStats as $value) { ?>
                        <tr>
                            <td class = "text-light border border-warning" ><?= $value['weight']; ?>kg</td>
                            <td class = "text-light border border-warning"><?= $value['height']; ?>cm</td>
                            <td class = "text-light border border-warning"><?= $value['bmi']; ?></td>
                            <td class = "text-light border border-warning"><?= $value['date']; ?></td>
                            <td class = "text-light border border-warning"><?= $value['minutes']; ?>mins</td>
    
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <!-- If there is no record activity show error -->
            <p class="alert  alert-dark">You have not yet recorded any activities in this category.</p>
        <?php } ?>

       
    </div>
    <?php require_once('includes/footer.php'); ?>
</body>
</html>
