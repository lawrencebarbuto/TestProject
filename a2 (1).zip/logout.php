<!-- Log user out from account -->
<?php
    require_once('includes/functions.php');

    logoutUser();
    header('Location: login.php');
    exit();
