    <!-- User can only access when user is logged in -->
<?php require_once('includes/authorise.php'); ?>
<?php
    $user = getLoggedInUser();
    $category = getCategory($_GET['category']);
    $userStats = getUserStatsForCategory($user['email'], $category['key']);

    $errors = [];
    if(isset($_POST['createActivity'])) {
        $errors = createActivity($_POST, $user['email'], $category['key']);

        if(count($errors) === 0) {
            header("Location: category.php?category={$category['key']}");
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<title>Record Activity</title>
<head>
    <?php require_once('includes/header.php'); ?>
    <?php require_once('includes/body.php'); ?>
</head>

<body>
    <?php require_once('includes/navbar.php'); ?>

    <div class="createActivity bg-dark text-center"><br>
        <div class="mb-3 text-light text-center">
            <h1> <?= $category['name']; ?></h1><br>
            <h1>
                <img  class="border rounded" src="<?= $category['image']; ?>" class="d-block d-sm-inline-block" />
            </h1><br><br><br>
        </div>
<!-- Creating Form for recording activity -->
        <div class="row" >
            <div class="col-md-12 d-flex justify-content-center">
                <form method="post text-center">
                <div class="form-group text-center ">
                        <label for="weight" class="text-light">
                            *Weight
                            <small class="text-light">
                                in kg
                            </small>
                        </label>
                        <!-- Validating Weight -->
                        <input type="text" id="weight" name="weight" class = "form-control" 
                        value="<?php if (isset($_POST['weight'])) echo $_POST['weight']; ?>"/>
                        <?php displayError($errors, 'weight'); ?>
                    </div>

                    <div class="form-group">
                        <label for="height" class="text-light">
                            *Height
                            <small class="text-light">
                                in cm
                            </small>
                        </label>
                        <!-- Validating Height -->
                        <input type="text" id="height" name="height" class = "form-control"   value="<?php if (isset($_POST['height'])) echo $_POST['height']; ?>">

                        <?php displayError($errors, 'height'); ?>
                    </div>

                    <div class="form-group">
                        <label for="bmi" class="text-light">
                            *BMI
                        </label>
                        <!-- Validating BMI -->
                        <input type="text" id="bmi" name="bmi" class = "form-control" value="<?php if (isset($_POST['bmi'])) echo $_POST['bmi']; ?>">
                        <?php displayError($errors, 'bmi'); ?>
                    </div>

                    
                    <div class="form-group">
                        <label for="date" class="text-light">
                            *Date
                            <small class="text-light">
                                start date
                            </small>
                        </label>
                        <!-- Validating Date -->
                        <input type="date" id="date" name="date" class = "form-control">
                            <?php displayValue($_POST, 'date'); ?>
                        <?php displayError($errors, 'date'); ?>
                    </div>

                    <div class="form-group">
                        <label for="minutes" class="text-light">
                            *Weekly Goal
                            <small class="text-light">
                                in mins
                            </small>
                        </label>
                        <!-- Validating Time -->
                        <input type="text" class="form-control" id="minutes" name="minutes"
                            <?php displayValue($_POST, 'minutes'); ?> />
                        <?php displayError($errors, 'minutes'); ?>
                    </div>

                    <button type="submit" class="btn btn-primary mr-5" name="createActivity" value="createActivity">
                        Create activity
                    </button>
                    <a href="category.php?category=<?= $category['key']; ?>" class="btn btn-outline-light">Cancel</a> <br><br>
                </form>
            </div>
        </div>
       
    </div>
     <?php require_once('includes/footer.php'); ?>
</body>
</html>
