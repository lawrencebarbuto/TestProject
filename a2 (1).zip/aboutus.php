<?php require_once('includes/functions.php'); ?>
<!DOCTYPE html>
<html lang="en">
<title>About Us</title>

<head>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/body.php'); ?>
</head>
    <style>
        /* Creating Banner */
        .banner {
            width: 1885px;
            height: 150px;
            color: white;
            line-height: 150px;
            font-size: 70px;
            text-align: center;
            text-transform: uppercase;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background: black;
            border-width: 1px;
        }

        p {
            text-align: top;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            font-size: 50px;
            color: white;
        }
/* Designing about us pages */
        .aboutus {
            width: 1885px;
            height: 900px;
            color: white;
            font-size: 70px;
            text-align: center;
            background-color: rgba(44, 44, 44, 0.8);
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
        }

        p.one {
            font-size: 100px;
            color: white;
            font-family: fantasy;
        }

        p.two {
            font-size: 30px;
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

</style>

<body>
    <!-- Putting Everything together on the page -->
    <?php require_once('includes/navbar.php'); ?>
        <div class="banner">
            <p>About Us</p>
        </div><br>
        <div class="aboutus">
            <p class="one">Why Us? <br><br></p>
            <p class="two">We have dedicated ourself to serve everyone who joins us here. <br> We offer various services
                from cardio to 30 days dieting to ensure you area lso always in top shape. <br> Plus we have 24/7
                Gym!<br><br><br>
                To also ensure that you stay active during this Covid-19 Season we have moved everything online.<br>
                Come join the fun today with our lovely staffs, you will never get bored of the addrenaline buzz, we
                guarantee it!<br>
            </p>
        </div>

    </div>

    <?php require_once('includes/footer.php'); ?>
</body>

</html>

