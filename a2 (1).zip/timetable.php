<?php require_once('includes/functions.php'); ?>
<!DOCTYPE html>
<html lang="en">
<title>Timetable</title>

<head>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/body.php'); ?>
    <style>
        /* Making Timetable */
        /* Image screenshot from Fitness first Australia */
        .timetable {
            width: 3000px;
            height: 900px;
            color: white;
            line-height: 50px;
            font-size: 70px;
            margin-left: 400px;
            text-align: center;
            text-transform: uppercase;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background-image: url("assets/workout.png");
            background-repeat: no-repeat;
            border-width: 1px;
        }

        /* Creating Banner */
        .banner {
            width: 1885px;
            height: 150px;
            color: white;
            line-height: 150px;
            font-size: 70px;
            text-align: center;
            text-transform: uppercase;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background: black;
            border-width: 1px;
        }
</style>
    </style>
</head>

<body>
    <!-- Putting Everything together on the page -->
    <?php require_once('includes/navbar.php'); ?>
        <div class="banner">
            <p>Class Timetable</p>
        </div><br>
        
        <div class="timetable">
        </div>

    <?php require_once('includes/footer.php'); ?>
</body>

</html>