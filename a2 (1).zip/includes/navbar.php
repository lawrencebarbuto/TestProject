<!-- Creating Navigation Bar -->
<style>
    .navbar-custom { 
    line-height: 45px;
    background-color:  rgba(44, 44, 44, 0.50);
    } 

    ul.nav li a {
        background-color:  rgba(44, 44, 44, 0.80);
            font-size: 22px;
            color: white;
            text-align: center;
    }

    ul.nav li a:hover, ul.nav li a:active {
        background-color: steelblue;
            color: white;
    }

    ul.nav li a:visited{
        color: darkorchid;
    }


     .header {
            text-align: center;
            background: linear-gradient(110deg, #070707 50%, rgb(118, 158, 203) 50%);
            width: 400px;
            height: 150px;
            color: white;
            font-size: 65px;
            font-family: bahnschrift;
            line-height: 1;
            text-shadow:
                1px 1px slategray,
                1px 2px slategray,
                1px 3px slategray;
        }
</style>

<nav class="navbar navbar-expand-md navbar-custom mb-3">
<div class="header">Adrenaline Buzz Club</div>
    <div class="navbar">
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
            </div> 
                <div class="navbar-nav ml-auto">
                <ul class="nav">
                    <!-- Both logged in and not logged in user can see this in navbar -->
                <li><a href="index.php" class="nav-item nav-link mx-2 " >Home</a></li>
                <li><a href="timetable.php" class="nav-item nav-link mx-2">Timetable</a></li>
<!-- If user is logged in show: -->
                <?php if(isUserLoggedIn()) { ?>
                    <li><a href="myFitness.php" class="nav-item nav-link mx-2">myFitness</a></li>
                <?php } ?>
                <?php if(isUserLoggedIn()) { ?>
                    <span class="nav-item nav-link text-light mx-2" style="font-size:20px;">
                        Welcome, <?= getLoggedInUser()['firstname']; ?>
                    </span>
                    <li><a href="logout.php" class="nav-item nav-link mx-2">Logout</a></li>
                <?php } else { ?>
<!-- If user is not logged in show: -->
                    <li><a href="services.php" class="nav-item nav-link mx-2">Class & Services</a></li>
                    <li><a href="registration.php" class="nav-item nav-link mx-2 ">Register</a></li>
                    <li><a href="login.php" class="nav-item nav-link mx-2">Login</a></li>
                    <li><a href="aboutus.php" class="nav-item nav-link mx-2">About Us</a></li>
                    <li><a href="contactus.php" class="nav-item nav-link mx-2">Contact Us</a></li>
                <?php } ?>
                
            </div> 
        </div>
</nav>

