<!-- User is required to login to access the page -->
<?php
    require_once('functions.php');

    if(!isUserLoggedIn()) {
        header('Location: login.php');
        exit();
    }
