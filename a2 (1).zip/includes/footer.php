<style>
    .footer {
            text-align:left;
            width: 1885px;
            height: 10px;
            color: white;
        }
    p.footer{
        text-align: left;
            margin-block-start: 0;
            margin-block-end: 0;
            color: white;
            font-size: 20px;
    }

    a.sitemap{
            margin-block-start: -1em;
            margin-block-end: -1em;
            text-align: right;
            color: white;
            font-size: 20px;
    }
</style>
<footer>
    <div class="footer">
            <p class = "footer">Adrenaline Buzz Club &copy; 2020</p>
            <div class="col-md-20 text-md-right">
            <a href="sitemap.php" class="sitemap">Sitemap</a>
        </div>

    </div>
</footer>

