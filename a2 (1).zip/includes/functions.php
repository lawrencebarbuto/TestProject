<?php
    const USERS_PATH = 'data/users.json';
    const USER_STATS_PATH = 'data/user_stats.json';
    const CATEGORIES_PATH = 'data/categories.json';

    const USER_SESSION_KEY = 'user';

    const MINUTES_MINIMUM = 1;
    const MINUTES_MAXIMUM = 720;

    const WEIGHT_MINIMUM = 5;
    const WEIGHT_MAXIMUM = 635;

    const HEIGHT_MINIMUM = 57;
    const HEIGHT_MAXIMUM = 255;

    const BMI_MINIMUM = 7;
    const BMI_MAXIMUM = 200;




    // Always call session_start.
    session_start();

    // --- Utils ----------------------------------------------------------------------------------
    function readJsonFile($path) {
        $json = file_get_contents($path);

        return json_decode($json, true);
    }

    function updateJsonFile($data, $path) {
        $json = json_encode($data, JSON_PRETTY_PRINT);
        file_put_contents($path, $json, LOCK_EX);
    }

    function displayError($errors, $name) {
        if(isset($errors[$name]))
            echo "<div class='text-danger'>{$errors[$name]}</div>";
    }

    function displayValue($form, $name) {
        if(isset($form[$name]))
            echo 'value="' . htmlspecialchars($form[$name]) . '"';
    }

    // Use for creating password hash
    function generatePasswordHash($password, $salt = null) {
        if($salt === null)
            $salt = bin2hex(openssl_random_pseudo_bytes(10));
        $blowfish_salt = '$2y$10$' . $salt;

        return crypt($password, $blowfish_salt);
    }

    // Use for verifying password hash
    function verifyPasswordHash($password, $hash) {
        $tokens = explode('$', $hash);
        $salt = $tokens[3];

        return $hash === generatePasswordHash($password, $salt);
    }


    // --- Categories -----------------------------------------------------------------------------
    function readCategories() {
        return readJsonFile(CATEGORIES_PATH);
    }

    function getCategory($category) {
        $categories = readCategories();

        return isset($categories[$category]) ? $categories[$category] : null;
    }

    // --- User Stats -----------------------------------------------------------------------------
    function readUserStats() {
        return readJsonFile(USER_STATS_PATH);
    }

    function updateUserStats($userStats) {
        updateJsonFile($userStats, USER_STATS_PATH);
    }

    function getUserStats($email) {
        $userStats = readUserStats();

        // An empty array is returned if stats are not set - used to streamline the code for readind & inserting.
        return isset($userStats[$email]) ? $userStats[$email] : [];
    }

    function getUserStatsForCategory($email, $category) {
        $userStats = getUserStats($email);

        // An empty array is returned if stats are not set - used to streamline the code for readind & inserting.
        return isset($userStats[$category]) ? $userStats[$category] : [];
    }

    function createActivity($form, $email, $category) {
        $errors = [];
// Validating weight
        $key = 'weight';
        if(!isset($form[$key]) || filter_var($form[$key], FILTER_VALIDATE_INT,
            ['options' => ['min_range' => WEIGHT_MINIMUM, 'max_range' => WEIGHT_MAXIMUM]]) === false)
        {
            $errors[$key] =
                implode(['Weight is required and must be between ', WEIGHT_MINIMUM, ' and ', WEIGHT_MAXIMUM, '.']);
        }
        // Validating height
        $key = 'height';
        if(!isset($form[$key]) || filter_var($form[$key], FILTER_VALIDATE_INT,
            ['options' => ['min_range' => HEIGHT_MINIMUM, 'max_range' => HEIGHT_MAXIMUM]]) === false)
        {
            $errors[$key] =
                implode(['Height is required and must be between ', WEIGHT_MINIMUM, ' and ', WEIGHT_MAXIMUM, '.']);
        }
            // Validating bmi
        $key = 'bmi';
        if(!isset($form[$key]) || filter_var($form[$key], FILTER_VALIDATE_INT,
            ['options' => ['min_range' => BMI_MINIMUM, 'max_range' => BMI_MAXIMUM]]) === false)
        {
            $errors[$key] =
                implode(['BMI is required and must be between ', BMI_MINIMUM, ' and ', BMI_MAXIMUM, '.']);
        }
// Validating date
        $key = 'date';
        if(!isset($form[$key]) || strtotime($form[$key]) > time() )
            $errors[$key] = 'Date is required and must not be a future date';

        $key = 'minutes';
        if(!isset($form[$key]) || filter_var($form[$key], FILTER_VALIDATE_INT,
            ['options' => ['min_range' => MINUTES_MINIMUM, 'max_range' => MINUTES_MAXIMUM]]) === false)
        {
            $errors[$key] =
                implode(['Minutes is required and must be between ', MINUTES_MINIMUM, ' and ', MINUTES_MAXIMUM, '.']);
        }
        // Convert validated minutes to an integer for future use (storing as number rather than string in JSON).
        else
            $form[$key] = (int) $form[$key];

        if(count($errors) === 0) {
            // Add activity.
            $activity = [
                'weight' => htmlspecialchars(trim($form['weight'])),
                'height' => htmlspecialchars(trim($form['height'])),
                'bmi' => htmlspecialchars(trim($form['bmi'])),
                'date' => htmlspecialchars(trim($form['date'])),
                'minutes' => $form['minutes'],
                
            ];

            $userStats = readUserStats();
            $userStats[$email][$category][] = $activity;

            // Update file.
            updateUserStats($userStats);
        }

        return $errors;
    }

    // --- User -----------------------------------------------------------------------------------
    function readUsers() {
        return readJsonFile(USERS_PATH);
    }

    function updateUsers($users) {
        updateJsonFile($users, USERS_PATH);
    }

    function getUser($email) {
        $users = readUsers();

        return isset($users[$email]) ? $users[$email] : null;
    }

    function isUserLoggedIn() {
        return isset($_SESSION[USER_SESSION_KEY]);
    }

    function getLoggedInUser() {
        return isUserLoggedIn() ? $_SESSION[USER_SESSION_KEY] : null;
    }
// Validating user login
    function loginUser($form) {
        $errors = [];
// Validating email
        $key = 'email';
        if(!isset($form[$key]) || filter_var($form[$key], FILTER_VALIDATE_EMAIL) === false)
            $errors[$key] = 'Email is invalid.';
// Validating password
        $key = 'password';
        if (strlen($form['password']) <= 6) {
            $errors[$key] = "Your Password is invalid.";
        }
            
// If there are no errors, proceed
        if(count($errors) === 0) {
            $user = getUser($form['email']);

            // If using PHP >= 5.5 use the password_verify function.
            // if($user !== null && password_verify($form['password'], $user['password-hash']))
            if($user !== null && verifyPasswordHash($form['password'], $user['password-hash']))
                // Login user.
                $_SESSION[USER_SESSION_KEY] = $user;
            else
                $errors[$key] = 'Login failed, email and / or password incorrect. Please try again.';
        }

        return $errors;
    }

    function logoutUser() {
        session_unset();
        // OR
        // unset($_SESSION[USER_SESSION_KEY]);
    }

// Validating registered user
    function registerUser($form) {
        $errors = [];
// Validating firstname
        $key = 'firstname';
        if(!isset($form[$key]) || preg_match('/^\s*$/', $form[$key]) === 1)
            $errors[$key] = 'First name is required.';
// Validating lastname
        $key = 'lastname';
        if(!isset($form[$key]) || preg_match('/^\s*$/', $form[$key]) === 1)
            $errors[$key] = 'Last name is required.';
// Validating email
        $key = 'email';
        if(!isset($form[$key]) || filter_var($form[$key], FILTER_VALIDATE_EMAIL) === false)
            $errors[$key] = 'Email is invalid.';
        else if(getUser($form[$key]) !== null)
            $errors[$key] = 'Email is already registered.';

// Validating password
        $key = 'password';
        if (strlen($form['password']) <= 6) {
            $errors[$key] = "Your Password Must Contain At Least 6 Characters!";
        }
        elseif(!preg_match('/[A-Z]{1,}/',$form[$key])) {
            $errors[$key] = "Your Password Must Start with a Capital Letter!";
        
        }
        elseif(!preg_match('/(?=[!^&])/',$form[$key])) {
            $errors[$key] = "Your Password Must Contain Either !, ^, &";
        
        }
        
        elseif(!preg_match('/[0-9]$/',$form[$key])) {
            $errors[$key] = "Your Password Must End with a Number!";
        }

// Validating confirm password
        $key = 'confirmPassword';
        if(isset($form['password']) && (!isset($form[$key]) || $form['password'] !== $form[$key]))
            $errors[$key] = 'Passwords do not match.';
// Validating refferal
        $key = 'refferal';
        if(!isset($form['refferal'])){ 
            $errors[$key] = "No buttons were checked."; 
        } 
    
// Validating membertype        
        $key = 'membertype';
        if(isset($form['membertype']) && $form['membertype'] == ""){
            $errors[$key] = "Please select a Member Type"; 
        }
        
 // Validating age     
        $key = 'age';
        if(($form['age']) < 16) {
            $errors[$key]= "Must be 16 to Register";
            } 
// Validating duration     
        $key = 'duration';
        if(isset($form['membertype']) && $form['membertype'] == ""){
            $errors[$key] = "Please select a Member Type";
        }
        
//If there are no errors, proceed
        if(count($errors) === 0) {
            // Add user.
            $user = [
                'firstname' => htmlspecialchars(trim($form['firstname'])),
                'lastname' => htmlspecialchars(trim($form['lastname'])),
                'email' => htmlspecialchars(trim($form['email'])),
                'password-hash' => generatePasswordHash($form['password']),
                'address' => htmlspecialchars(trim($form['address'])),
                'refferal' => htmlspecialchars(trim($form['refferal'])),
                'membertype' => htmlspecialchars(trim($form['membertype'])),
                'age' => htmlspecialchars(trim($form['age'])),
                'duration' => htmlspecialchars(trim($form['duration']))
          
            ];

            $users = readUsers();
            $users[$user['email']] = $user;

            // Update file.
            updateUsers($users);

            // Auto-login registered user.
            loginUser([
                'email' => $user['email'],
                'password' => $form['password']
            ]);
        }

        return $errors;
    }

