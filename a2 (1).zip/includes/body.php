<style>
        body {
            margin: 10px;
            min-height: 100vh;
            background-image: url("assets/background.jpg");
            background-repeat: repeat;

        }
</style>