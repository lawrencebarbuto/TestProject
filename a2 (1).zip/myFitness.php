<!-- If user is not logged in they cannot access the page -->
<?php require_once('includes/authorise.php'); ?>
<!DOCTYPE html>
<html lang="en">
    <title>myFitness</title>
<head>
    <?php require_once('includes/header.php'); ?>
    <?php require_once('includes/body.php'); ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>


<body>
    <?php require_once('includes/navbar.php'); ?>
    <div class="myfitness bg-dark">
   
        <div class="mb-3">
            <br><h1 class = "text-light text-center">Welcome to myFitness!<h1>
            <h5 class = "text-light text-left">Search bar:<h5>
                <!-- Creating SearchBar -->
            <input type="text" name="search" id="search" class="col-md-4" />
        <button type="submit" class="btn btn-secondary" name="search" value="search">Search</button>
    <ul class="list-group" id="result"></ul>
   <br />
            <h2 class = "text-light text-center"><br><br><br><br>Choose from any of the following categories of exercises:</h2><br>
        </div>

        <div class="row">
            <!-- Creating Categories to click on -->
            <?php foreach(readCategories() as $key => $value) { ?>
                <div class="col-sm-6 col-md-4 col-lg-4 text-center text-light">
                    <a href="category.php?category=<?= $key; ?>">
                        <img class="border rounded" src="<?= $value['image']; ?>" />
                    </a>
                    <h1><?= $value['name']; ?></h1><br><br><br><br>
                </div>
            <?php } ?>
        </div>
    </div>
    <?php require_once('includes/footer.php'); ?>
</body>

<!-- Validating Searchbar with AJAX -->
<script>
$(document).ready(function(){
 $.ajaxSetup({ cache: false });
 $('#search').keyup(function(){
  $('#result').html('');
  $('#state').val('');
  var searchField = $('#search').val();
  var expression = new RegExp(searchField, "i");
  $.getJSON('data/categories.json', function(data) {
   $.each(data, function(key, value){
    if (value.name.search(expression) != -1 )
    {
    
        $('#result').append('<li class="list-group-item link-class"><img class="border rounded" src="'+value.image+'" height="60" width="60" /> '+value.name+'</li>');

    }
   });   
  });
 });
 
 $('#result').on('click', 'li', function() {
  var click_text = $(this).text().split('|');
  $('#search').val($.trim(click_text[0]));
  $("#result").html('');
 });
});
</script>
</html>

