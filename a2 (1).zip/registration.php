<?php require_once('includes/functions.php'); ?>
<!-- If user is registed and does not have any errors, go to login.php page -->
<?php
    $errors = [];
    if(isset($_POST['registeration'])) {
        $errors = registerUser($_POST);

        if(count($errors) === 0) {
            header('Location: myFitness.php');
            exit();
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once('includes/header.php'); ?>
    <?php require_once('includes/body.php'); ?>
</head>
<style>
        /* Making Banner */
        .banner {
            width: 1885px;
            height: 150px;
            color: white;
            line-height: 150px;
            font-size: 70px;
            text-align: center;
            text-transform: uppercase;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background: black;
            border-width: 1px;
        }

        p {
            text-align: top;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            font-size: 70px;
            color: white;
        }

        /* Designing registration form */
        .registration {
            width: 1885px;
            height: 100%;
            background-color: rgba(44, 44, 44, 0.8);
            
        }
  
        .row{
            color: white;
            line-height: 50px;
            width: 900px;
            height: 100%;
            font-size: 20px;
            text-align: left;
            
            
        }

        .col-md-6{
            margin-left:700px;
            height: 100%;
        }


</style>

<body>
    <?php require_once('includes/navbar.php'); ?>
    <div class= "banner">
        <p>Registraion Form</p>
    </div><br>
    
    <div class ="registration">
        <div class="row">
            <div class="col-md-6">
                <form method="post">
                    <div class="form-group">
                        <!-- Validate Firstname -->
                        <label for="firstname">*First name</label>
                        <input type="text" class="form-control" id="firstname" name="firstname"
                            <?php displayValue($_POST, 'firstname'); ?> />
                        <?php displayError($errors, 'firstname'); ?>
                    </div>

                    <div class="form-group">
                        <!-- Validate Lastname -->
                        <label for="lastname">*Last name</label>
                        <input type="text" class="form-control" id="lastname" name="lastname"
                            <?php displayValue($_POST, 'lastname'); ?> />
                        <?php displayError($errors, 'lastname'); ?>
                    </div>

                    <div class="form-group">
                        <!-- Validate Email -->
                        <label for="lastname">*Email</label>
                        <input type="text" class="form-control" id="email" name="email"
                            <?php displayValue($_POST, 'email'); ?> />
                        <?php displayError($errors, 'email'); ?>
                    </div>


                    <div class="form-group">
                        <!-- Validate Password -->
                        <label for="password">*Password <small class="text-muted">must be at least 6 characters</small></label>
                        <input type="password" class="form-control" id="password" name="password" />
                        <?php displayError($errors, 'password'); ?>
                    </div>

                    <div class="form-group">
                        <!-- Validate Confirm Password -->
                        <label for="password">*Confirm password</label>
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" />
                        <?php displayError($errors, 'confirmPassword'); ?>
                    </div>

                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea name="address" value="" id="address" style = "width: 500px;"></textarea>
                    
                    </div>

                    <div class="form-group">
                        <!-- Validate Referral -->
                        <label for="referral">*Refferal:</label> <br>
                        <input type="radio" name="refferal"  value="yes"<?php if(isset($_POST['refferal']) && $_POST['refferal'] =='yes' ){echo "checked";}?>/> Yes
                        <input type="radio" name="refferal" value="no"<?php if(isset($_POST['refferal']) && $_POST['refferal'] =='no' ){echo "checked";}?>/> No
                        <?php displayError($errors, 'refferal'); ?>
  
                    </div>

                    <div class = "form-group" >
                        <!-- Validate Membertype -->
                    <lable for="membertype">*Member Type: <br>
                        <select name="membertype" id="membertype">
                        <option value="">Choose your Member Type</option>
                        <option <?php if ($_POST['membertype'] == 'Individual') { ?>selected="true" <?php }; ?>value="Individual">Individual</option>
                        <option <?php if ($_POST['membertype'] == 'Family') { ?>selected="true" <?php }; ?>value="Family">Family</option>
                        </select>
                        <?php displayError($errors, 'membertype'); ?>

                        
                    </div>

                    <div class="form-group">
                        <!-- Validate Age -->
                        <label for="age">*Age</label>
                        <input type="range" min="12" max="100" value="12" class="age" id="age" name = "age" oninput="this.form.amount.value=this.value">
                        <output type="number" name="amount" min="12" max="100" value="12" oninput="this.form.age.value=this.value" >
                        <?php displayError($errors, 'age'); ?>

                    </div>

                    <div class = "form-group" >
                        <!-- Validate Membership Duration -->
                    <lable for="duration">*Membership Duration: <br>
                        <select name="duration" id="duration">
                        <option value="" >Choose your Membership Duration</option>
                        <option <?php if ($_POST['duration'] == 'Ongoing') { ?>selected="true" <?php }; ?>value="Ongoing">On going</option>
                        <option <?php if ($_POST['duration'] == '3Months') { ?>selected="true" <?php }; ?>value="3Months">3 Months</option>
                        <option <?php if ($_POST['duration'] == '6Months') { ?>selected="true" <?php }; ?>value="6Months">6 Months</option>
                        <option <?php if ($_POST['duration'] == 'Yearly') { ?>selected="true" <?php }; ?>value="Yearly">Yearly</option>
                        </select>
                        <?php displayError($errors, 'duration'); ?>
                        
                    </div>
                    
                    <button type="submit" class="btn btn-primary mr-5" name="registeration" value="Registeration">Registration</button>
                    <a href="index.php" class="btn btn-outline-light">Cancel</a>

                </form><br><br>
            </div>
        </div>
    </div>

    <?php require_once('includes/footer.php'); ?>
</body>
</html>
