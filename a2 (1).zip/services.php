<?php require_once('includes/functions.php'); ?>
<!DOCTYPE html>
<html lang="en">
<title>Class & Services</title>

<head>
<?php require_once('includes/header.php'); ?>
<?php require_once('includes/body.php'); ?>
    <style>
        /* Creating Banner */
        .banner {
            width: 1885px;
            height: 150px;
            color: white;
            line-height: 150px;
            font-size: 70px;
            text-align: center;
            text-transform: uppercase;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background: black;
            border-width: 1px;
        }

        p {
            text-align: top;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            font-size: 50px;
            color: white;
        }

        /* Making Content */
        .services {
            float: left;
            width: 1885px;
            height:100%;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            border-width: 1px;
            border: outset rgb(44, 44, 44);
        }

        p.one {
            text-align: center;
            text-align: top;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            font-size: 17.5px;
            color: white;
        }

        p.two {
            text-align: left;
            margin-left: 50px;
            text-decoration: underline;
            font-size: 75px;
            color: steelblue;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        p.three {
            text-align: left;
            margin-left: 50px;
            color: white;
            font-size: 30px;
            line-height: 1.2;
        }

        /* Video from Pexels */
        video {

            float: right;
            margin: 50px;
        }

        a.two:link {
            float: left;
            margin-left: 50px;
            font-family: Arial, Helvetica, sans-serif;
            font-weight: 50px;
            font-size: 45px;
            background-color: rgb(65, 64, 64);
            color: white;
            border: 2px solid;
            border-radius: 25px;
            padding: 20px 20px;
        }

        /* Link will change when you hover */
        a.two:hover {
            background-color: white;
            color: steelblue;
            border: 2px;
            border-radius: 25px;
            padding: 20px 20px;
            text-align: center;
        }

        /* Link will change when you have visited the page */
        a.two:visited {
            color: rgb(214, 70, 70);
        }

        p.four {
            text-align: right;
            margin-right: 50px;
            text-decoration: underline;
            font-size: 75px;
            color: steelblue;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        p.five {
            text-align: right;
            margin-right: 50px;
            color: white;
            font-size: 30px;
            line-height: 1.2;
        }

        /* Video from Pexels */
        video.two {

            float: left;
            margin: 50px;
        }

        a.three:link {
            float: right;
            margin-right: 50px;
            font-family: Arial, Helvetica, sans-serif;
            font-weight: 50px;
            font-size: 45px;
            background-color: rgb(65, 64, 64);
            color: white;
            border: 2px solid;
            border-radius: 25px;
            padding: 20px 20px;
        }

        /* Link will change when you hover */
        a.three:hover {
            background-color: white;
            color: steelblue;
            border: 2px;
            border-radius: 25px;
            padding: 20px 20px;
            text-align: center;
        }

        /* Link will change when you have visited the page */
        a.three:visited {
            color: rgb(214, 70, 70);
        }

</style>
    </style>
</head>

<body>
    <!-- Putting Everything together on the page -->
    <?php require_once('includes/navbar.php'); ?>
        <div class="banner">
            <p>Class & Services</p>
        </div><br>
        <div class ="services">
            <p class="one">due to covid-19 we are transffering our classes virtually</p>

            <!-- Cardio Classes -->
            <video width="700px" height="500px" controls>
                <source src="assets/video1.mp4" type="video/mp4">
            </video>
            <p class="two">Cardio Classes</p>
            <p class="three">Cardio classes are cartered towards those who are looking to <br> burn calories and help
                you relax.
                <br>Additionally, it also helps you sleep well at night. </p>
            <a class="two" href="timetable.php" target="_self">Cardio Classes</a>
            <p><br><br><br><br><br></p>
            <!-- Strength Classes -->
            <video class="two" width="700px" height="500px" controls>
                <source src="assets/video2.mp4" type="video/mp4">
            </video>
            <p class="four"><br>Strength Classes</p>
            <p class="five">Strength Classes are for those are working towards building <br> their muscles and
                strengths.</p>
            <a class="three" href="timetable.php" target="_self">Strength Classes</a>
            <p><br><br><br><br><br></p>
            <!-- Kickboxing Classes -->
            <video width="700px" height="500px" controls>
                <source src="assets/video3.mp4" type="video/mp4">
            </video>
            <p class="two">Kickboxing Classes</p>
            <p class="three">Kickboxing classes teaches you have to fight and at the <br> same time help you burn
                calories and
                <br>build endurance. </p>
            <a class="two" href="timetable.php" target="_self">Kickboxing Classes</a>
        </div>

    <?php require_once('includes/footer.php'); ?>
</body>

</html>