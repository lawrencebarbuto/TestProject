<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Sitemap</title>

    <!-- CSS for breadcrumbs -->
    <link rel="stylesheet" href="styles/breadcrumbs.css">

    <!-- jQuery CDN -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- include the jQuery breadcrumbs plugin -->
    <script src="plugins/jquery.breadcrumbs-generator.js"></script>

    <!-- you will need to write this to invoke/use the plugin -->
    <script>
        $(function() {
            $('#breadcrumbs').breadcrumbsGenerator(); //will be displayed in <ol> element
        });
    </script>

</head>

<body>


    <ol id="breadcrumbs"></ol>

    <nav id="sitemap">
        <h2>Sitemap</h2>
        <ul>
            <li>
                <a href="index.php">Home</a>
            </li>

            <li>
                <a href="timetable.php">Timetable</a>
            </li>

            <li>
                <a href="services.php">Class & Services</a>
            </li>
                <ul>

                    <li><a href="timetable.php">Cardio Classes</a></li>
                    <li><a href="timetable.php">Strength Classes</a></li>
                    <li><a href="timetable.php">Kickboxing Classes</a></li>
                </ul>
                    
                <li><a href="registration.php">Registration</a></li>
                <li><a href="login.php">Log In</a></li>
                <ul>
                    <li>
                        <a href="myFitness.php">MyFitness</a>
                        <ul>
                            <li><a href="category.php">Categories</a></li>

                        </ul>
                            <ul>
                                <li><a href = "createActivity.php">Record Activity</a></li>
                            </ul>
                    </li>
                <li><a href="logout.php">Log Out</a></li>
                </ul>
                <li><a href="aboutus.php">About Us</a></li>
                <li><a href="contactus.php">Contact Us</a></li>
        </ul>
    </nav>
</body>

</html>