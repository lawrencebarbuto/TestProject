<?php require_once('includes/functions.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php require_once('includes/header.php'); ?>
    <?php require_once('includes/body.php'); ?>
</head>
    <style>

        /* Making Content */
        .index {
            float: left;
            width: 1885px;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            border-width: 1px;
            border: outset rgb(44, 44, 44);


        }

        /* Designing Link */
        a.two:link {
            margin-left: 150px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-weight: 50px;
            font-size: 60px;
            background-color: rgb(65, 64, 64);
            color: white;
            border: 2px solid;
            border-radius: 25px;
            padding: 20px 20px;
            text-align: center;
        }

        /* Link will change when you hover */
        a.two:hover {
            background-color: white;
            color: steelblue;
            border: 2px;
            border-radius: 25px;
            padding: 20px 20px;
            text-align: center;
        }

        /* Link will change when you have visited the page */
        a.two:visited {
            color: rgb(214, 70, 70);
        }

        /* Image from Pexels */
        img{

            float: right;
            margin: 50px;
            width: 650px;
            height: 850px;
        }

       
        p {
            text-align: center;
            text-align: top;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            font-size: 17.5px;
            color: white;
        }

        p.four {
            text-align: center;
            font-size: 100px;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            color: white;
        }

        p.one {
            text-align: left;
            margin-left: 150px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin-top: 200px;
            color: white;
            font-size: 35px;
        }
        /* Creating Link */
        a.three:link {
            float:right;
            margin-right: 150px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-weight: 50px;
            font-size: 60px;
            background-color: rgb(65, 64, 64);
            color: white;
            border: 2px solid;
            border-radius: 25px;
            padding: 20px 20px;
        }

        /* Link will change when you hover */
        a.three:hover {
            background-color: white;
            color: steelblue;
            border: 2px;
            border-radius: 25px;
            padding: 20px 20px;
            text-align: center;
        }

        /* Link will change when you have visited the page */
        a.three:visited {
            color: rgb(214, 70, 70);
        }


        p.five {
            text-align: right;
            margin-right: 150px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin-top: 200px;
            color: white;
            font-size: 35px;
        }
        /* Image from pexels */
        img.one{

            float: left;
            margin: 50px;
            width: 650px;
            height: 850px;
        }

    </style>

<body>
    <!-- Putting Everything together on the page -->
    <?php require_once('includes/navbar.php'); ?>
    <div class="index">
        
            <p>due to covid-19 we are transffering our classes virtually</p>
            <p class = "four"> Welcome to Adrenaline Buzz Club!</p>
            <img src = "assets/image6.jpg"> <br><br><br>
            <p class="one">Adrenaline Buzz Club is ready to keep you all in shape <br>even with the pandemic going.
                <br> We are exicted to you show all the new features  we <br>have. <br> Register now so you don't miss out! <br><br><br>
            </p> 
            <a class="two" href="registration.php" target="_self">JOIN US TODAY!</a>
            <p><br><br><br><br><br><br><br><br><br></p><img class = "one" src = "assets/image7.jpg">
            <p class="five"><br><br><br>Adrenaline Buzz Club provides various gym classes. <br> Not sure what class to take?<br>
                Head to our link below to see our class times! <br><br><br>
            </p> 
            <a class="three" href="timetable.php" target="_self">Fitness Classes</a>
            
    </div>
        
    <?php require_once('includes/footer.php'); ?>
</body>

</html>