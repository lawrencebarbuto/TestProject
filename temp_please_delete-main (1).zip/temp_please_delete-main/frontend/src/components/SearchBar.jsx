const SearchBar = () => {
    return (
        <div>
            <p>Find your nearest clinic</p>
            <form>
                <input
                    placeholder="Enter your suburbs or postcode"
                    type="text"
                    name="query"
                    id="query"
                />
                <input type="submit" value="Search" />
            </form>
        </div>
    );
};

export default SearchBar;
