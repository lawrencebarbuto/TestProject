import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";

import { osmProvider } from "../osm-provider";

const Map = () => {
    return (
        <MapContainer center={[-37.813629, 144.963058]} zoom={13}>
            <TileLayer
                attribution={osmProvider.mapTiler.attribution}
                url={osmProvider.mapTiler.url}
            />
            <Marker position={[-37.813629, 144.963058]}>
                <Popup>
                    A pretty CSS3 popup. <br /> Easily customizable.
                </Popup>
            </Marker>
        </MapContainer>
    );
};

export default Map;
