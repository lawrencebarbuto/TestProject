import "./app.css";
import SearchBar from "./components/SearchBar";
import Map from "./components/Map";

const App = () => {
    return (
        <div style={{ display: "flex", height: "100vh" }}>
            <div
                className="sideBar"
                style={{
                    maxWidth: "400px",
                    width: "100%",
                    display: "flex",
                    flexDirection: "column",
                    placeItems: "center",
                }}
            >
                <div
                    className="centerBar"
                    style={{
                        maxWidth: "300px",
                        margin: "0 auto",
                        marginTop: "30px",
                        display: "flex",
                        flexDirection: "column",
                        placeItems: "center",
                        gap: "20px",
                    }}
                >
                    <h1>Covid Wait App</h1>
                    <SearchBar />
                </div>
            </div>
            <Map />
        </div>
    );
};

export default App;
