import Express from "express";

const app = Express();
const PORT = 8080;

app.get("/", (req, res) => {
    res.status(200).send("Hello World");
});

app.get("/search", (req, res) => {
    res.status(200).send(req.query);
});

app.post("/checkin", (req, res) => {
    res.status(200).send("Checked in is called");
});

app.listen(PORT, () =>
    console.log("listening in port http://localhost:" + PORT)
);
