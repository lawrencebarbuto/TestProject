<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link
            rel="stylesheet"
            href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
            crossorigin="anonymous"
        />
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
            integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w=="
            crossorigin="anonymous"
        />
        <link rel="stylesheet" href="./style/register.css" />
        <title>Covid Wait App</title>
    </head>

    <body>
        <header>
            <div class="logo">
                <a href="index.html"
                    ><h1 class="text-center">
                        Covid Wait Time<i class="far fa-clock"></i></h1
                ></a>
            </div>
        </header>
        <div class="wrapper">
            <div class="title-text">
                <div class="title login">Login Form</div>
                <div class="title signup">Signup Form</div>
            </div>
            <div class="form-container">
                <div class="slide-controls">
                    <input type="radio" name="slide" id="login" checked />
                    <input type="radio" name="slide" id="signup" />
                    <label for="login" class="slide login">Login</label>
                    <label for="signup" class="slide signup">Signup</label>
                    <div class="slider-tab"></div>
                </div>
                <div class="form-inner">
                    <form action="#" class="login">
                        <div class="field">
                            <input
                                type="text"
                                placeholder="Email Address"
                                required
                            />
                        </div>
                        <div class="field">
                            <input
                                type="password"
                                placeholder="Password"
                                required
                            />
                        </div>
                        <div class="pass-link">
                            <a href="#">Forgot password?</a>
                        </div>
                        <div class="field btn">
                            <div class="btn-layer"></div>
                            <input type="submit" value="Login" />
                        </div>
                        <div class="signup-link">
                            Not a member? <a href="">Signup now</a>
                        </div>
                    </form>
                    <form action="#" class="signup">
                        <div class="field">
                            <input
                                type="text"
                                placeholder="Email Address"
                                required
                            />
                        </div>
                        <div class="field">
                            <input
                                type="password"
                                placeholder="Password"
                                required
                            />
                        </div>
                        <div class="field">
                            <input
                                type="password"
                                placeholder="Confirm password"
                                required
                            />
                        </div>
                        <div class="field btn">
                            <div class="btn-layer"></div>
                            <input type="submit" value="Signup" />
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script src="index.js"></script>
    </body>
</html>
