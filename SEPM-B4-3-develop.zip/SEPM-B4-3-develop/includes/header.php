<header>
    <div class="logo">
        <a href="/"
            ><h1 class="text-center">
                Covid Wait Time<i class="far fa-clock"></i></h1
        ></a>
    </div>
    <div class="topnav" id="myTopnav">
        <a href="checkin.php">Check-in</a>
        <a href="vaccination.php">Vaccination</a>
        <a href="register.php">Register</a>
        <!-- <a href="#">Login</a> -->
    </div>
</header>