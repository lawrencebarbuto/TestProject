<?php
header("Content-Type: application/json; charset=UTF-8");

$res = new stdClass();
$res->clientId = sha1(rand());
$res->success = true;

$resJSON = json_encode($res);

echo $resJSON;

